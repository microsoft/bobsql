
These are demos for the presentation at SQLBits 2018 on SQL Server 2017