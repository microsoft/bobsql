use WideWorldImporters
go
exec initialize
go