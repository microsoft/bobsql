use WideWorldImporters
go
exec auto_tune
go